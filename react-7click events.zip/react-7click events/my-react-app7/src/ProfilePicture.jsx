
function ProfilePicture(){

    const imgurl = './src/profile.jpg';
    
    const handleClick = (e) => e.target.style.display="none";
    
    return (<img className="width" onClick={ (e) => handleClick(e)}src= {imgurl}></img>);

}
export default ProfilePicture 